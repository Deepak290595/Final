
function validate(){
	if(validateCode("code",/^[A-Za-z0-9]+$/)){
		if(validateName("name",/^[A-Za-z ]+$/)){
			if(validatePinCode("pin",/^[0-9]{6}$/)){
				if(validateEmail("mail",/^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/)){
					if(validateNum("num",/^[0-9]{10}$/)){
						return true;
					}
				}
			}return false;
		}return false;
	}else 
		return false;
	
}

function validateCode(fieldname,regex){
	var object = document.forms["customerForm"][fieldname];
	if(object.value.match(regex))
		return true;
	else{
		window.alert(fieldname+" should be alpha-numeric with no spaces");
		object.focus();
		return false;
	}
}
function validateName(fieldname,regex){
	var object = document.forms["customerForm"][fieldname];
	if(object.value.match(regex))
		return true;
	else{
		window.alert(fieldname+" should be alphabets");
		object.focus();
		return false;
}
}
function validatePinCode(fieldname,regex){
	var object = document.forms["customerForm"][fieldname];
	if(object.value.match(regex))
		return true;
	else{
		window.alert(fieldname+" should be 6 digit number");
		object.focus();
		return false;
}
}
function validateEmail(fieldname,regex){
	var object = document.forms["customerForm"][fieldname];
	if(object.value.match(regex))
		return true;
	else{
		window.alert(fieldname+" should be a valid email format");
		object.focus();
		return false;
}
}
function validateNum(fieldname,regex){
	var object = document.forms["customerForm"][fieldname];
	if(object.value.match(regex))
		return true;
	else{
		window.alert(fieldname+" should be a phone number with ten digits");
		object.focus();
		return false;
}
}