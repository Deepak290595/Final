package com.nucleus.model.domain;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;


@SuppressWarnings("serial")
@Entity
@Table(name="Customer_deepak_final")
public class Customer implements Serializable{
	@Id
	@Length(min=1,max=10)
	private String customerCode;
	@NotNull
	@Length(min=5,max=30)
	@Pattern(regexp="^[A-Za-z0-9 ]+$")
	private String customerName;
	@NotNull
	@Length(min=1,max=100)
	private String customerAddress;
	@NotNull
	@Length(min=6,max=6)
	@Pattern(regexp="^[0-9]+$")
	private String customerPinCode;
	@Length(min=10,max=100)
	@Pattern(regexp="^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")
	private String customerEmail;
	@Length(min=10,max=10)
	@Pattern(regexp="^[0-9]+$")
	private String customerNumber;
	private String registrationDate;
	private String createdBy;
	private String modifiedDate;
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	@Override
	public String toString() {
		return "Customer [customerCode=" + customerCode + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPinCode=" + customerPinCode + ", customerEmail=" + customerEmail
				+ ", customerNumber=" + customerNumber + ", registrationDate=" + registrationDate + ", createdBy="
				+ createdBy + ", modifiedDate=" + modifiedDate + "]";
	}
	public Customer(String customerCode, String customerName, String customerAddress, String customerPinCode,
			String customerEmail, String customerNumber, String registrationDate, String createdBy,
			String modifiedDate) {
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerPinCode = customerPinCode;
		this.customerEmail = customerEmail;
		this.customerNumber = customerNumber;
		this.registrationDate = registrationDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
	}
	public Customer() {
	}
	
	}
