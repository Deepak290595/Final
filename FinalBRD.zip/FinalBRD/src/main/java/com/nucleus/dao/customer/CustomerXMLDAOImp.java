package com.nucleus.dao.customer;


import java.util.Collections;
import java.util.List;
import com.nucleus.model.domain.Customer;


public class CustomerXMLDAOImp implements CustomerDAO {

	@Override
	public void save(Customer customer) {
	}

	@Override
	public boolean delete(Customer customer) {
		return false;
	}
	
	@Override
	public List<Customer> view(String code) {
		return Collections.emptyList();
	}

	@Override
	public List<Customer> viewAll() {

		return Collections.emptyList();
	}
	@Override
	public void update(Customer customer) {
	}

	@Override
	public List<Customer> viewByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	

/*	@Override
	public List<Customer> viewAllPagination(int number) {
		return Collections.emptyList();
	}*/
} 
