package com.nucleus.dao.user;

import com.nucleus.model.domain.User;
import com.nucleus.model.domain.UserRole;


public interface UserDAO {
	public void saveUser(User user);
	public void saveRole(UserRole role);
}
