package com.nucleus.dao.customer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.model.domain.Customer;

@Repository
@Transactional
public class CustomerRDBMSDAOImp implements CustomerDAO{

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public void save(Customer customer) {
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			customer.setRegistrationDate(dateFormat.format(date));
			sessionFactory.getCurrentSession().persist(customer);
	}

	@Override
	public boolean delete(Customer customer) {
		boolean exist= true;
		try{
			sessionFactory.getCurrentSession().delete(customer);
		}catch (DataAccessException e) {
			exist = false;
			return exist;
		}
		return exist;
	}

	@Override
	public List<Customer> view(String code) {
		List<Customer> customers = new ArrayList<Customer>();
		customers.add((Customer) sessionFactory.getCurrentSession().get(Customer.class, code));
		return customers;
	}

	@Override
	public List<Customer> viewAll() {
		Query query = sessionFactory.getCurrentSession().createQuery("from Customer");
		List<Customer> customers = query.list();
		return customers;
	}

	@Override
	public void update(Customer customer) {
		Date date = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			customer.setModifiedDate(dateFormat.format(date));
			sessionFactory.getCurrentSession().update(customer);
	}

	@Override
	public List<Customer> viewByName(String name) {
		Query query = sessionFactory.getCurrentSession().createQuery("from Customer where customerName=?");
		query.setParameter(0, name);
		List<Customer> customers = query.list();
		return customers;
	}

	/*@Override
	public List<Customer> viewAllPagination(int number) {
		// TODO Auto-generated method stub
		return null;
	}
		*/

}
