package com.nucleus.dao.customer;



public class CustomerDAOFactory {
	private CustomerDAOFactory(){}
	public static CustomerDAO getObject(String impType){
		if(impType.equals("rdbms"))
			return new CustomerRDBMSDAOImp();
		else if(impType.equals("xml"))
			return new CustomerXMLDAOImp();
		else
			return null;
		
	}
}
