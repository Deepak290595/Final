package com.nucleus.dao.user;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nucleus.bcrypt.PasswordEncoder;
import com.nucleus.model.domain.User;
import com.nucleus.model.domain.UserRole;

@Repository
@Transactional
public class UserRDBMSDAOImp implements UserDAO {

	@Autowired
	SessionFactory sessionFactory;
	@Override
	public void saveUser(User user) {
		user.setUserPassword(PasswordEncoder.encodePwd(user.getUserPassword()));
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}

	@Override
	public void saveRole(UserRole role) {
		sessionFactory.getCurrentSession().persist(role);
	}

}
