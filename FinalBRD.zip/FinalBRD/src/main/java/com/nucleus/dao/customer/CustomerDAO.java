package com.nucleus.dao.customer;

import java.util.List;

import com.nucleus.model.domain.Customer;

public interface CustomerDAO {
	public void save(Customer customer);
	public boolean delete(Customer customer);
	public List<Customer> view(String code);
	public List<Customer> viewAll();
	public void update(Customer customer);	
	//public List<Customer> viewAllPagination(int number);
	public List<Customer> viewByName(String name);
}
