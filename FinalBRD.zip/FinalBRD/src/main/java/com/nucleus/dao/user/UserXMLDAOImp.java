package com.nucleus.dao.user;

import com.nucleus.model.domain.User;
import com.nucleus.model.domain.UserRole;

public class UserXMLDAOImp implements UserDAO {

	@Override
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveRole(UserRole role) {
		// TODO Auto-generated method stub
		
	}

}
