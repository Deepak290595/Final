package com.nucleus.dao.user;

public class UserDAOFactory {
	private UserDAOFactory(){}
	public static UserDAO getObject(String impType){
		if(impType.equals("rdbms"))
			return new UserRDBMSDAOImp();
		else if(impType.equals("xml"))
			return new UserXMLDAOImp();
		else
			return null;
		
	}
}
