package com.nucleus.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.domain.Customer;
import com.nucleus.service.customer.CustomerService;

@Controller
public class CustomerControl {
	@Autowired
	CustomerService service;
	@RequestMapping("/newCustomerSubmit")
	public ModelAndView save(@Valid Customer customer,BindingResult bindingResult){
		if(bindingResult.hasErrors()){
			System.out.println(bindingResult);
			return new ModelAndView("NewCustomer","message","Error");
		}else{
		if(service.save(customer)){
			return new ModelAndView("NewCustomer","message","Already Exist");
			}
		ModelAndView modelAndView = new ModelAndView("NewCustomer");
		modelAndView.addObject("customer", new Customer());
		modelAndView.addObject("message", "Successfully Saved");
		return modelAndView;
	}
	}
	@RequestMapping("/delete")
	public ModelAndView delete(Customer customer){
		if(service.delete(customer.getCustomerCode())){
			return new ModelAndView("Delete","message","Successfully Deleted");
		}
		return new ModelAndView("Delete","message","No records Found");
	}
	@RequestMapping("/update")
	public ModelAndView update(Customer customer){
		if(service.view(customer.getCustomerCode()).contains(null))
			return new ModelAndView("UpdatePage","message","No Records Found");
		return new ModelAndView("Update","customerDetails",service.view(customer.getCustomerCode()).get(0));
	}
	@RequestMapping("/singleView")
	public ModelAndView singleView(Customer customer){
		if(service.view(customer.getCustomerCode()).contains(null))
			return new ModelAndView("SingleView","message","No Records Found");
		return new ModelAndView("View","customerDetails",service.view(customer.getCustomerCode()));
	}

	@RequestMapping("/viewAll")
	public ModelAndView allView(){
		if(service.viewAll().isEmpty())
			return new ModelAndView("ViewAll","message","No Records Found");
		return new ModelAndView("ViewAll","customerDetails",service.viewAll());
	}
	@RequestMapping("/update2")
	public ModelAndView update2(@Valid Customer customer,BindingResult result){
		if(result.hasErrors())
			return new ModelAndView("Update");
		else{
			if(service.update2(customer))
				return new ModelAndView("UpdatePage","message","Successfully Updated");
			else
				return new ModelAndView("UpdatePage","message","Cannot perform Update");
		
		}
	}
	@RequestMapping("/singleViewName")
	public ModelAndView singleViewName(Customer customer){
		if(service.viewByName(customer.getCustomerName()).isEmpty())
			return new ModelAndView("ViewByName","message","No Records Found");
		return new ModelAndView("View","customerDetails",service.viewByName(customer.getCustomerName()));
	}
	/*@RequestMapping("/viewAllPagination")
	public ModelAndView viewAllPagination(HttpServletRequest request,HttpServletResponse response){
		List<Customer> customerList = new ArrayList<Customer>();
		String action = request.getParameter("action");
		if(action==null){
			request.setAttribute("pageNumber",0);
			int pageNumber = (Integer) request.getAttribute("pageNumber");
			customerList = service.viewAllPagination(pageNumber);
			request.setAttribute("customerDetails", customerList);
			return new ModelAndView("ViewAllPagination");
		}
		else if(action.equals("Next")){
			int pageNumber = Integer.parseInt((String) request.getParameter("pageNumber"));
			customerList = service.viewAllPagination(pageNumber+10);
				if(customerList.isEmpty()){
					return new ModelAndView("errorPage");
				}else
					{
					request.setAttribute("customerDetails", customerList);
					pageNumber = Integer.parseInt((String)request.getParameter("pageNumber"));
					request.setAttribute("pageNumber", pageNumber+10);
					return new ModelAndView("ViewAllPagination");
					}
		}
		else if(action.equalsIgnoreCase("previous")){
			int pageNumber = Integer.parseInt((String) request.getParameter("pageNumber"));
			customerList = service.viewAllPagination(pageNumber-10);
			if(customerList.isEmpty()){
				return new ModelAndView("errorPage");
			}else
			{
				request.setAttribute("customerDetails", customerList);
				pageNumber = Integer.parseInt((String) request.getParameter("pageNumber"));
				request.setAttribute("pageNumber", pageNumber-10);
				return new ModelAndView("ViewAllPagination");
			}
		}
		return null;
	}*/
}

