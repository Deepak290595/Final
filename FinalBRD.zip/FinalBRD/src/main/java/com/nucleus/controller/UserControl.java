package com.nucleus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.model.domain.User;
import com.nucleus.service.user.UserService;

@Controller
public class UserControl {
	
	@Autowired
	UserService userService;
	@RequestMapping("/newUser")
	public String newUser(User user){
		return "NewUser";
	}
	@RequestMapping("/newUserSubmit")
	public ModelAndView save(User user){
		userService.saveUser(user);
		return new ModelAndView("NewUser","message","Saved Successfully");
	}
}
