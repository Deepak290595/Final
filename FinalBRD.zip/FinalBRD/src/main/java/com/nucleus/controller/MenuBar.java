package com.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nucleus.model.domain.Customer;

@Controller
public class MenuBar {

	@RequestMapping("/MakerHome")
	public String home(){
		return "MakerHome";
	}
	
	@RequestMapping("/NewCustomer")
	public String newCustomer(Customer customer){
		return "NewCustomer";
	}
	@RequestMapping("/deletePage")
	public String deletePage(Customer customer){
		return "Delete";
	}
	@RequestMapping("/updatePage")
	public String updatePage(Customer customer){
		return "UpdatePage";
	}
	@RequestMapping("/singleViewPage")
	public String singleViewPage(Customer customer){
		return "SingleView";
	}
	@RequestMapping("/viewByName")
	public String viewByName(Customer customer){
		return "ViewByName";
	}
}
