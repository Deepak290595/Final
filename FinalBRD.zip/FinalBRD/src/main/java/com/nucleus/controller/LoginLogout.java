package com.nucleus.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginLogout {
	
	final static Logger logger = Logger.getLogger(LoginLogout.class);
	
	@RequestMapping("/login")
	public String login(){
		return "LoginPage";
	}
	@RequestMapping("/defaultPage")
	public String defaultPage(HttpServletRequest request){
		String targetURL = null;
		if(request.isUserInRole("ROLE_ADMIN"))
			targetURL ="redirect:/home";
		else if(request.isUserInRole("ROLE_USER"))
			targetURL = "redirect:/home";
		return targetURL;
	}
	@RequestMapping("/home")
	public String home(){
		return "Home";
	}
	@RequestMapping("/logout")
	public ModelAndView logout(){
		return new ModelAndView("LoginPage","message","Successfully LoggedOut");
	}
	@RequestMapping("/failure")
	public ModelAndView failure(){
		return new ModelAndView("LoginPage","message","Bad Credentials");
	}
	@RequestMapping("/errorpage")
	public String error(){
		return "ErrorPage";
	}
}
