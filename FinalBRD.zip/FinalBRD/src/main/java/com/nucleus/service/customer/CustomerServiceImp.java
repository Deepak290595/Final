package com.nucleus.service.customer;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import com.nucleus.dao.customer.CustomerDAO;
import com.nucleus.model.domain.Customer;
@Service
public class CustomerServiceImp implements CustomerService {
	@Autowired
	CustomerDAO dao;
	List<Customer> customerList = new ArrayList<Customer>();
	@Override
	public boolean save(Customer customer) {
		boolean unique= false;
		try{
			dao.save(customer);
		}catch (DataIntegrityViolationException e) {
			unique=true;
			return unique;
		}
		return unique;
	}
	
	@Override
	public boolean delete(String code) {
		Customer customer=dao.view(code).get(0);
		return dao.delete(customer);
	}
	@Override
	public List<Customer> view(String code) {
		customerList = dao.view(code);
		return customerList;
	}
	@Override
	public List<Customer> viewAll() {
		customerList = dao.viewAll();
		return customerList;
	}
	@Override
	public Customer update1(String code) {
		try{
		return dao.view(code).get(0);
		}
		catch(Exception e){
			return null;
		}
	}
	@Override
	public boolean update2(Customer customer) {
		boolean updated=true;
		try{
			dao.update(customer);
		}
		catch (DataAccessException e) {
			updated = false;
			return updated;
		}
		return updated;
	}

	/*@Override
	public List<Customer> viewAllPagination(int number) {
		customerList = dao.viewAllPagination(number);
		return customerList;
	}
*/
	@Override
	public List<Customer> viewByName(String customerName) {
		customerList = dao.viewByName(customerName);
		return customerList;
	}

}
