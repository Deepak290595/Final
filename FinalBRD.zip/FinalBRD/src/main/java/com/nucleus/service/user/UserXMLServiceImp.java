package com.nucleus.service.user;

import com.nucleus.model.domain.User;
import com.nucleus.model.domain.UserRole;

public class UserXMLServiceImp implements UserService {

	@Override
	public boolean saveUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean saveRole(UserRole role) {
		// TODO Auto-generated method stub
		return false;
	}

}
