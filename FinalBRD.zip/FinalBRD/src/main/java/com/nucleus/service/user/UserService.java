package com.nucleus.service.user;

import com.nucleus.model.domain.User;
import com.nucleus.model.domain.UserRole;

public interface UserService {
	public boolean saveUser(User user);
	public boolean saveRole(UserRole string);
}
