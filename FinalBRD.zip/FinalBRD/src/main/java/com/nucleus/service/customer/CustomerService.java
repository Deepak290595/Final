package com.nucleus.service.customer;

import java.util.List;

import com.nucleus.model.domain.Customer;

public interface CustomerService {
	public boolean save(Customer customer);
	public boolean delete(String string);
	public List<Customer> view(String customerCode);
	public List<Customer> viewAll();
	public Customer update1(String customerCode);
	public boolean update2(Customer customer);
	//public List<Customer> viewAllPagination(int number);
	public List<Customer> viewByName(String customerName);
	
}
