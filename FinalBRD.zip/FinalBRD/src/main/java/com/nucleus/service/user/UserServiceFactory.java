package com.nucleus.service.user;

public class UserServiceFactory {
	private UserServiceFactory(){}
	public static UserService getObject(String impType){
		if(impType.equals("rdbms"))
			return new UserServiceImp();
		else if(impType.equals("xml"))
			return new UserXMLServiceImp();
		else
			return null;
		
	}
}
