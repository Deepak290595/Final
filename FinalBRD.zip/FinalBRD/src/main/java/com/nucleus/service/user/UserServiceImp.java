package com.nucleus.service.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.dao.user.UserDAO;
import com.nucleus.model.domain.User;
import com.nucleus.model.domain.UserRole;

@Service
public class UserServiceImp implements UserService {
	@Autowired
	UserDAO dao;

	@Override
	public boolean saveUser(User user) {
		dao.saveUser(user);
		return false;
	}

	@Override
	public boolean saveRole(UserRole role) {
		dao.saveRole(role);
		return false;
	}

}
