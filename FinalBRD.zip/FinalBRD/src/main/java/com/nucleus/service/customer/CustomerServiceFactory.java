package com.nucleus.service.customer;


public class CustomerServiceFactory {
	private CustomerServiceFactory(){}
	public static CustomerService getObject(String impType){
		if(impType.equals("rdbms"))
			return new CustomerServiceImp();
		else if(impType.equals("xml"))
			return new CustomerXMLServiceImp();
		else
			return null;
		
	}
}
